def add_one(numer):
    return numer + 1
